/**
 * Whop checkout modal.
 *
 * Uses ONLY Whop Payment Elements — no custom card forms, no Stripe/PayPal
 * code anywhere in this template.
 *
 * - <Checkout plan={planId}> mints the checkout session from the plan.
 *   The plan defines the price; nothing about amounts is asserted client-side.
 * - ExpressCheckoutElement (Apple Pay / Google Pay) and CheckoutElement
 *   (full card form) are EXCLUSIVE in one Checkout handle (docs:
 *   elements/latest/checkout/checkout + expressCheckout): "Mount one at a
 *   time. Destroy it before mounting another." So this modal shows the
 *   express buttons first and swaps to the full form on "Pay with card
 *   instead" — exactly one is mounted at any moment.
 * - Financing (Klarna / Splitit / Afterpay, etc.) is NOT built here: it
 *   surfaces automatically inside Whop checkout for approved merchants.
 *   This site never collects card numbers itself.
 * - onComplete fires on a completed checkout; fulfilment must come from
 *   the payment.succeeded webhook, not from this callback (it can refire
 *   when a checkout is restored).
 * - BrandingElement: required inside <Payments> (see CardOnFile.tsx) —
 *   payment/card elements stay loading until it is mounted, and payments
 *   cannot be confirmed without it. The Checkout surface renders Whop's
 *   own merchant-of-record notice itself.
 */
import { useEffect, useState } from "react";
import {
  WhopElements,
  Checkout,
  CheckoutElement,
  ExpressCheckoutElement,
} from "@whop/elements-react";
import { loadWhop } from "@whop/elements";
import { formatUsd, isPlanConfigured, type RoofingPlan } from "../../config";
import { trackDepositStarted, trackWhop } from "../../lib/tracking";

export function CheckoutModal({
  plan,
  onClose,
}: {
  plan: RoofingPlan;
  onClose: () => void;
}) {
  const [mode, setMode] = useState<"express" | "full">("express");
  const [done, setDone] = useState(false);
  const configured = isPlanConfigured(plan);

  useEffect(() => {
    if (plan.key === "deposit") trackDepositStarted();
    else trackWhop("initiate_checkout", { value: plan.priceUsd, currency: "USD" });
  }, [plan]);

  return (
    <div className="modal-backdrop" role="dialog" aria-modal="true" aria-label={`Checkout — ${plan.name}`}>
      <div className="modal">
        <div className="modal-head">
          <div>
            <h2>{plan.name}</h2>
            <p className="muted">
              {formatUsd(plan.priceUsd)} one-time · Secure checkout by Whop
            </p>
          </div>
          <button className="btn btn-ghost" onClick={onClose} aria-label="Close checkout">
            ✕
          </button>
        </div>

        {!configured ? (
          <div className="notice notice-warn">
            <strong>This plan is not configured yet.</strong> Paste the real{" "}
            <code>plan_…</code> ID for “{plan.name}” into <code>src/config.ts</code>{" "}
            (see README “Create the plans”) — checkout is disabled until then, so
            nobody can pay for a plan that does not exist.
          </div>
        ) : done ? (
          <div className="notice notice-ok">
            <strong>Payment complete — thank you.</strong> We’ll email your
            receipt and call you within one business day to confirm the date.
            {plan.key === "deposit" && (
              <>
                {" "}Your card is saved on file for the final balance — see
                “Save a card for the final balance” below if you used the
                card-on-file step instead.
              </>
            )}
          </div>
        ) : (
          <>
            <div className="checkout-toggle" role="tablist" aria-label="Checkout method">
              <button
                className={mode === "express" ? "active" : ""}
                onClick={() => setMode("express")}
              >
                 Pay / Google Pay
              </button>
              <button
                className={mode === "full" ? "active" : ""}
                onClick={() => setMode("full")}
              >
                Pay with card
              </button>
            </div>
            <p className="muted small">
              {mode === "express"
                ? "One-tap wallet checkout. Only the wallets your device and this checkout support will appear."
                : "Full Whop checkout — card, financing options, and promo codes, all inside Whop."}
            </p>
            <WhopElements elements={loadWhop()}>
              <Checkout
                plan={plan.planId}
                onComplete={() => setDone(true)}
              >
                {mode === "express" ? (
                  <ExpressCheckoutElement
                    wallets={{ applePay: "auto", googlePay: "auto", payPal: "never" }}
                  />
                ) : (
                  <CheckoutElement />
                )}
              </Checkout>
            </WhopElements>
            {mode === "express" && (
              <button className="btn btn-ghost" onClick={() => setMode("full")}>
                Prefer to pay with a card instead →
              </button>
            )}
          </>
        )}

        <p className="muted small">
          Payments are processed by Whop (merchant of record). This site never
          sees or stores your card number. Financing options appear inside
          checkout automatically for approved buyers.
        </p>
      </div>
    </div>
  );
}
