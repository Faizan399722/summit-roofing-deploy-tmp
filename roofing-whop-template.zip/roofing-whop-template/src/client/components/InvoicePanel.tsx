/**
 * Final-balance invoice panel — the office side of the deposit → job →
 * final invoice flow.
 *
 * How it works (developer/guides/invoices, native API):
 *   1. Create a draft: POST /invoices { account_id, items: [{ plan_id }],
 *      email_address, customer_name, due_at, payment_method_id? }.
 *      A draft charges nothing and emails nobody.
 *   2. Issue it: POST /invoices/{id}/issue — final tax is calculated and
 *      the invoice opens. If the draft carries a saved payment_method_id
 *      (payt_… from the deposit's setup intent), Whop auto-charges it
 *      off-session (at charge_at / due_at, otherwise right away).
 *   3. Or send it: POST /invoices/{id}/send — issues it AND emails it, so
 *      the customer pays manually through Whop's hosted checkout
 *      (checkout_link). If an auto-charge is declined, Whop emails the pay
 *      link anyway.
 *   Fulfil from the payment.succeeded webhook for the invoice's pay_ ID.
 *
 * This panel is a demo/admin surface for the pitch video — in production,
 * gate it behind the office login and pre-fill it from the job record.
 * TODO per job: the real final amount. Invoices bill a plan's price, so a
 * custom final total needs a one-time variant created for that amount
 * first (see README "Final balance"); pass its planId here.
 */
import { useState, type FormEvent } from "react";
import { siteConfig } from "../../config";
import { createFinalBalanceInvoice } from "../../lib/api";

export function InvoicePanel() {
  const [email, setEmail] = useState("");
  const [customerName, setCustomerName] = useState("");
  const [planKey, setPlanKey] = useState("deposit");
  const [paymentMethodId, setPaymentMethodId] = useState("");
  const [action, setAction] = useState<"create" | "issue" | "send">("issue");
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    setResult(null);
    try {
      const plan = siteConfig.plans.find((p) => p.key === planKey);
      if (!plan) throw new Error("Unknown plan.");
      const inv = await createFinalBalanceInvoice({
        email,
        customerName,
        planId: plan.key,
        paymentMethodId: paymentMethodId.trim() || undefined,
        dueDays: 14,
        action,
        memo: `Final balance — ${siteConfig.company.name} roofing project`,
      });
      setResult(
        `Invoice ${inv.invoiceId} — status: ${inv.status}.` +
          (inv.checkoutLink ? ` Manual pay link: ${inv.checkoutLink}` : "") +
          (action === "issue" && paymentMethodId.trim()
            ? " Saved card will be auto-charged off-session."
            : action === "send"
              ? " Emailed to the customer for manual payment."
              : " Draft only — nothing charged, nobody emailed."),
      );
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not create the invoice.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <section className="section section-alt" id="invoice">
      <div className="container">
        <h2>Final balance, by invoice</h2>
        <p className="lede">
          After the job is finished and walked through, the office bills the
          remaining balance here. <strong>Create</strong> saves a draft (no
          charge, no email). <strong>Issue</strong> opens it and auto-charges
          the card saved at deposit time. <strong>Send</strong> issues it and
          emails it so the customer pays manually through Whop checkout.
        </p>
        <form className="invoice-form" onSubmit={onSubmit}>
          <label className="field">
            <span>Customer email *</span>
            <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
          </label>
          <label className="field">
            <span>Customer name *</span>
            <input value={customerName} onChange={(e) => setCustomerName(e.target.value)} required />
          </label>
          <label className="field">
            <span>Bill which plan?</span>
            <select value={planKey} onChange={(e) => setPlanKey(e.target.value)}>
              {siteConfig.plans.map((p) => (
                <option key={p.key} value={p.key}>
                  {p.name} — ${p.priceUsd}
                </option>
              ))}
            </select>
          </label>
          <label className="field">
            <span>Saved payment method (payt_…) — optional</span>
            <input
              value={paymentMethodId}
              onChange={(e) => setPaymentMethodId(e.target.value)}
              placeholder="payt_xxxxxxxxxxxxxx — from the deposit setup intent"
            />
          </label>
          <label className="field">
            <span>What should happen?</span>
            <select value={action} onChange={(e) => setAction(e.target.value as typeof action)}>
              <option value="create">Create draft only</option>
              <option value="issue">Issue — auto-charge saved card</option>
              <option value="send">Send — email for manual payment</option>
            </select>
          </label>
          <button className="btn btn-primary" type="submit" disabled={busy}>
            {busy ? "Working…" : "Create final-balance invoice"}
          </button>
        </form>
        {result && <div className="notice notice-ok">{result}</div>}
        {error && <div className="notice notice-error"><strong>Invoice failed:</strong> {error}</div>}
        <p className="muted small">
          Office demo panel for the pitch — gate this behind your office login
          in production. Invoices are due 14 days from creation in this
          template.
        </p>
      </div>
    </section>
  );
}
