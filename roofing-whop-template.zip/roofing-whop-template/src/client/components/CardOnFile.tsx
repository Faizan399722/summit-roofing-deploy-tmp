/**
 * Card-on-file (save a payment method) for the final balance.
 *
 * Documented Whop flow (developer/guides/save-payment-methods):
 *   1. Mount the payment elements in mode="setup" — only methods that can
 *      be saved are offered, and the buyer sees the future-use consent.
 *   2. Call payments.createConfirmationToken() with billing details
 *      (email is required; cards also need name + line1/country).
 *   3. Server turns the confirmation token into a setup intent
 *      (POST /setup_intents) and returns client_secret for any next action.
 *   4. payments.handleNextAction({ clientSecret }) finishes 3DS etc.
 *   5. Listen for `setup_intent.succeeded` — its payment_method_id
 *      (payt_…) is what the final-balance invoice charges off-session.
 *
 * This flow is used TWO ways in the template:
 *   - Standalone: a homeowner who already paid the $500 deposit saves a
 *     card here so the final invoice can auto-charge it.
 *   - The deposit checkout itself can also save during payment by passing
 *     setupFutureUsage: "off_session" on the Payments handle (see README);
 *     the Checkout element path above charges the deposit, this path saves.
 *
 * BrandingElement is REQUIRED here: it mounts inside <Payments>, and the
 * docs state the payment/card elements stay in their loading state until
 * it is mounted, and payments cannot be confirmed without it.
 */
import { useState } from "react";
import {
  WhopElements,
  Payments,
  PaymentElement,
  EmailElement,
  BrandingElement,
  usePayments,
  useWhop,
  type PaymentElementChangeEvent,
} from "@whop/elements-react";
import { loadWhop } from "@whop/elements";
import { siteConfig } from "../../config";
import { createSetupIntent } from "../../lib/api";

function SaveCardForm({ onClose }: { onClose: () => void }) {
  const payments = usePayments();
  // handleNextAction is a static on the Whop instance (whop.payments.*),
  // not on the Payments handle — see @whop/elements PaymentsStatics.
  const whop = useWhop();
  const [email, setEmail] = useState("");
  const [ready, setReady] = useState(false);
  const [busy, setBusy] = useState(false);
  const [status, setStatus] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const configured =
    siteConfig.company.whopAccountId.startsWith("biz_") &&
    !siteConfig.company.whopAccountId.includes("REPLACE_ME");

  async function saveCard() {
    if (!payments) return;
    if (!email.trim()) {
      setError("Enter the email the card should be saved under.");
      return;
    }
    setBusy(true);
    setError(null);
    setStatus(null);
    try {
      const { confirmationToken } = await payments.createConfirmationToken({
        billingDetails: { email: email.trim() },
      });
      const intent = await createSetupIntent({
        confirmationToken,
        email: email.trim(),
      });
      if (intent.clientSecret) {
        if (!whop) throw new Error("Whop Elements is still loading — try again in a moment.");
        await whop.payments.handleNextAction({ clientSecret: intent.clientSecret });
      }
      setStatus(
        `Card saved. Setup intent ${intent.setupIntentId ?? "(see server logs)"} is ${intent.status ?? "processing"}. ` +
          `Watch for setup_intent.succeeded — its payment_method_id is what the final invoice charges.`,
      );
    } catch (e) {
      const message = e instanceof Error ? e.message : "Could not save the card.";
      setError(
        message === "payment_request_cancelled"
          ? "Cancelled — nothing was saved. You can try again."
          : message,
      );
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="modal-backdrop" role="dialog" aria-modal="true" aria-label="Save a card for the final balance">
      <div className="modal">
        <div className="modal-head">
          <div>
            <h2>Save a card for the final balance</h2>
            <p className="muted">
              No charge now. The card is saved so your final invoice can be
              auto-charged when the job is done — or you can pay it manually.
            </p>
          </div>
          <button className="btn btn-ghost" onClick={onClose} aria-label="Close">
            ✕
          </button>
        </div>

        {!configured ? (
          <div className="notice notice-warn">
            <strong>Whop account not configured yet.</strong> Set{" "}
            <code>whopAccountId</code> in <code>src/config.ts</code> and{" "}
            <code>WHOP_API_KEY</code> on the server first (see README).
          </div>
        ) : (
          <WhopElements elements={loadWhop()}>
            <Payments
              accountId={siteConfig.company.whopAccountId}
              mode="setup"
              currency="usd"
              setupFutureUsage="off_session"
            >
              <label className="field">
                <span>Email (for the saved card)</span>
                <EmailElement onChange={(e) => setEmail(e.email ?? "")} />
              </label>
              <PaymentElement
                onChange={(e: PaymentElementChangeEvent) => setReady(e.complete)}
              />
              <BrandingElement />
              <button
                className="btn btn-primary"
                disabled={!ready || busy}
                onClick={saveCard}
              >
                {busy ? "Saving…" : "Save card on file — $0 now"}
              </button>
            </Payments>
          </WhopElements>
        )}

        {status && <div className="notice notice-ok">{status}</div>}
        {error && <div className="notice notice-error">{error}</div>}
        <p className="muted small">
          By saving a card you consent to future off-session charges for the
          final balance of your roofing project only. You can remove the card
          or pay the invoice manually at any time.
        </p>
      </div>
    </div>
  );
}

export function SaveCardModal({ onClose }: { onClose: () => void }) {
  return <SaveCardForm onClose={onClose} />;
}
