/**
 * "Request an Estimate" form -> Whop Leads API (via POST /api/leads).
 *
 * The form never fakes a success: if the server has no Whop API key, or
 * Whop rejects the lead, the error is shown and nothing is reported as
 * created. On success, whop.track fires `estimate_requested` (+ standard
 * `lead`) — see src/lib/tracking.ts.
 */
import { useState, type FormEvent } from "react";
import { siteConfig } from "../../config";
import { submitEstimate, type EstimatePayload } from "../../lib/api";
import { trackEstimateRequested } from "../../lib/tracking";

const EMPTY: EstimatePayload = {
  name: "",
  email: "",
  phone: "",
  address: "",
  zip: "",
  service: "repair",
  details: "",
};

export function EstimateForm() {
  const [form, setForm] = useState<EstimatePayload>(EMPTY);
  const [busy, setBusy] = useState(false);
  const [sent, setSent] = useState(false);
  const [leadId, setLeadId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  function set<K extends keyof EstimatePayload>(key: K, value: string) {
    setForm((f) => ({ ...f, [key]: value }));
  }

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    setSent(false);
    setLeadId(null);
    try {
      const res = await submitEstimate(form);
      setSent(true);
      setLeadId(res.leadId ?? null);
      trackEstimateRequested(form.service);
    } catch (err) {
      const message = err instanceof Error ? err.message : "Could not send your request.";
      setError(message);
    } finally {
      setBusy(false);
    }
  }

  if (sent) {
    return (
      <div className="notice notice-ok">
        <strong>Request received — thank you, {form.name.split(" ")[0] || "friend"}.</strong>{" "}
        Your estimate request is in as a Whop lead
        {leadId ? <> (lead <code>{leadId}</code>)</> : null}. We’ll call or
        email you within one business day.{" "}
        <button className="btn btn-ghost" onClick={() => { setSent(false); setForm(EMPTY); }}>
          Send another request
        </button>
      </div>
    );
  }

  return (
    <form className="estimate-form" onSubmit={onSubmit}>
      <div className="form-grid">
        <label className="field">
          <span>Full name *</span>
          <input value={form.name} onChange={(e) => set("name", e.target.value)} required autoComplete="name" />
        </label>
        <label className="field">
          <span>Email *</span>
          <input type="email" value={form.email} onChange={(e) => set("email", e.target.value)} required autoComplete="email" />
        </label>
        <label className="field">
          <span>Phone</span>
          <input type="tel" value={form.phone} onChange={(e) => set("phone", e.target.value)} autoComplete="tel" placeholder="(555) 000-0000" />
        </label>
        <label className="field">
          <span>ZIP code</span>
          <input value={form.zip} onChange={(e) => set("zip", e.target.value)} inputMode="numeric" placeholder="80202" />
        </label>
        <label className="field field-wide">
          <span>Property address</span>
          <input value={form.address} onChange={(e) => set("address", e.target.value)} autoComplete="street-address" placeholder="Street address" />
        </label>
        <label className="field field-wide">
          <span>What do you need?</span>
          <select value={form.service} onChange={(e) => set("service", e.target.value)}>
            {siteConfig.services.map((s) => (
              <option key={s.key} value={s.key}>
                {s.name} — {s.tagline}
              </option>
            ))}
            <option value="general">Not sure yet — I need advice</option>
          </select>
        </label>
        <label className="field field-wide">
          <span>Tell us about the roof (leaks, age, storm damage…)</span>
          <textarea rows={4} value={form.details} onChange={(e) => set("details", e.target.value)} placeholder="e.g. Leak above the kitchen after the last storm. Roof is about 14 years old." />
        </label>
      </div>

      <button className="btn btn-primary btn-large" type="submit" disabled={busy}>
        {busy ? "Sending…" : "Request my free estimate"}
      </button>
      <p className="muted small">
        No spam, no obligation. We reply within one business day. Your details
        go straight to our team as a Whop lead.
      </p>

      {error && (
        <div className="notice notice-error">
          <strong>That didn’t go through:</strong> {error} Your details were
          not lost — please try again, or call us at{" "}
          <a href={siteConfig.company.phoneHref}>{siteConfig.company.phoneDisplay}</a>.
        </div>
      )}
    </form>
  );
}
