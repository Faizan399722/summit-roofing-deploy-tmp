import { useState } from "react";
import {
  siteConfig,
  formatUsd,
  getPlan,
  isPlanConfigured,
  type RoofingPlan,
  type RoofingService,
} from "../config";
import { trackServiceViewed } from "../lib/tracking";
import { EstimateForm } from "./components/EstimateForm";
import { CheckoutModal } from "./components/CheckoutModal";
import { SaveCardModal } from "./components/CardOnFile";
import { InvoicePanel } from "./components/InvoicePanel";

function Stars({ n }: { n: number }) {
  return <span aria-label={`${n} out of 5 stars`}>{"★".repeat(n)}</span>;
}

export default function App() {
  const [checkoutPlan, setCheckoutPlan] = useState<RoofingPlan | null>(null);
  const [saveCardOpen, setSaveCardOpen] = useState(false);
  const [openFaq, setOpenFaq] = useState<number | null>(null);

  function bookPlan(planKey: RoofingPlan["key"]) {
    const plan = getPlan(planKey);
    setCheckoutPlan(plan);
  }

  function viewService(service: RoofingService) {
    trackServiceViewed(service.key, service.name);
    document.getElementById("estimate")?.scrollIntoView({ behavior: "smooth" });
  }

  const c = siteConfig.company;

  return (
    <div className="site">
      <header className="topbar">
        <div className="container topbar-inner">
          <a className="brand" href="#top">
            <span className="brand-mark">⌂</span> {c.name}
          </a>
          <nav className="nav" aria-label="Main">
            <a href="#services">Services</a>
            <a href="#pricing">Pricing</a>
            <a href="#area">Service area</a>
            <a href="#financing">Financing</a>
            <a href="#reviews">Reviews</a>
          </nav>
          <a className="btn btn-primary btn-small" href="#estimate">
            Free estimate
          </a>
        </div>
      </header>

      <main id="top">
        {/* HERO */}
        <section className="hero">
          <div className="container hero-inner">
            <div>
              <p className="eyebrow">{c.license}</p>
              <h1>{siteConfig.hero.headline}</h1>
              <p className="lede">{siteConfig.hero.subheadline}</p>
              <div className="cta-row">
                <a className="btn btn-primary btn-large" href="#estimate">
                  {siteConfig.hero.primaryCta}
                </a>
                <button className="btn btn-secondary btn-large" onClick={() => bookPlan("inspection")}>
                  {siteConfig.hero.secondaryCta}
                </button>
              </div>
              <ul className="trust-points">
                {siteConfig.hero.trustPoints.map((t) => (
                  <li key={t}>✓ {t}</li>
                ))}
              </ul>
            </div>
            <aside className="hero-card" aria-label="Book in 2 minutes">
              <h2>Book in 2 minutes</h2>
              <p className="muted">No phone call needed. Pick a service, pay securely through Whop.</p>
              <ul className="hero-prices">
                {siteConfig.plans.map((p) => (
                  <li key={p.key}>
                    <span>{p.name}</span>
                    <strong>{formatUsd(p.priceUsd)}</strong>
                    <button className="btn btn-small" onClick={() => bookPlan(p.key)}>
                      Book
                    </button>
                  </li>
                ))}
              </ul>
              <p className="muted small">
                Or call <a href={c.phoneHref}>{c.phoneDisplay}</a> — {c.hours}
              </p>
            </aside>
          </div>
        </section>

        {/* SERVICES */}
        <section className="section" id="services">
          <div className="container">
            <h2>What we do</h2>
            <p className="lede">Three services, one standard: the price in writing before we start.</p>
            <div className="cards">
              {siteConfig.services.map((s) => (
                <article className="card" key={s.key}>
                  <h3>{s.name}</h3>
                  <p className="card-tag">{s.tagline}</p>
                  <p>{s.description}</p>
                  <ul className="checklist">
                    {s.bullets.map((b) => (
                      <li key={b}>✓ {b}</li>
                    ))}
                  </ul>
                  <p className="price-line">
                    {s.fromUsd ? <>From {formatUsd(s.fromUsd)}</> : "Priced per project — free estimate"}
                  </p>
                  <button className="btn btn-secondary" onClick={() => viewService(s)}>
                    Get an estimate for {s.name.toLowerCase()}
                  </button>
                </article>
              ))}
            </div>
          </div>
        </section>

        {/* PRICING / PLANS */}
        <section className="section section-alt" id="pricing">
          <div className="container">
            <h2>Simple, up-front pricing</h2>
            <p className="lede">
              Pay through Whop checkout — card, Apple Pay, Google Pay, or
              financing where available. The deposit is applied in full to your project.
            </p>
            <div className="cards">
              {siteConfig.plans.map((p) => (
                <article className="card plan-card" key={p.key}>
                  {p.key === "deposit" && <span className="badge">Most popular</span>}
                  <h3>{p.name}</h3>
                  <p className="plan-price">{formatUsd(p.priceUsd)}</p>
                  <p className="muted">{p.blurb}</p>
                  <ul className="checklist">
                    {p.includes.map((i) => (
                      <li key={i}>✓ {i}</li>
                    ))}
                  </ul>
                  <button
                    className="btn btn-primary"
                    onClick={() => bookPlan(p.key)}
                    disabled={!isPlanConfigured(p)}
                  >
                    {isPlanConfigured(p) ? `Book — ${formatUsd(p.priceUsd)}` : "Plan not configured yet"}
                  </button>
                  {!isPlanConfigured(p) && (
                    <p className="muted small">Add the real plan ID in src/config.ts to enable checkout.</p>
                  )}
                </article>
              ))}
            </div>
            <p className="center">
              <button className="btn btn-ghost" onClick={() => setSaveCardOpen(true)}>
                Already paid a deposit? Save a card for the final balance →
              </button>
            </p>
          </div>
        </section>

        {/* SERVICE AREA */}
        <section className="section" id="area">
          <div className="container">
            <h2>{siteConfig.serviceArea.heading}</h2>
            <p className="lede">{siteConfig.serviceArea.note}</p>
            <ul className="city-list">
              {siteConfig.serviceArea.cities.map((city) => (
                <li key={city}>{city}</li>
              ))}
            </ul>
          </div>
        </section>

        {/* FINANCING */}
        <section className="section section-dark" id="financing">
          <div className="container">
            <h2>{siteConfig.financing.heading}</h2>
            <p className="lede">{siteConfig.financing.body}</p>
            <ul className="checklist checklist-light">
              {siteConfig.financing.points.map((p) => (
                <li key={p}>✓ {p}</li>
              ))}
            </ul>
            <p className="muted small">
              Financing options (Klarna, Splitit, Afterpay, etc.) are offered by
              Whop at checkout for approved merchants and buyers — this template
              adds no financing code of its own.
            </p>
          </div>
        </section>

        {/* REVIEWS / TRUST */}
        <section className="section" id="reviews">
          <div className="container">
            <h2>Homeowners trust us with the roof over their heads</h2>
            <div className="cards">
              {siteConfig.reviews.map((r) => (
                <article className="card review-card" key={r.name}>
                  <Stars n={r.stars} />
                  <p>“{r.text}”</p>
                  <p className="muted small">{r.name}</p>
                </article>
              ))}
            </div>
          </div>
        </section>

        {/* ESTIMATE FORM */}
        <section className="section section-alt" id="estimate">
          <div className="container">
            <h2>Request a free estimate</h2>
            <p className="lede">
              Tell us about the roof. Your request lands directly with our team
              as a Whop lead — we reply within one business day.
            </p>
            <EstimateForm />
          </div>
        </section>

        {/* FINAL BALANCE INVOICE (office demo) */}
        <InvoicePanel />

        {/* FAQ */}
        <section className="section" id="faq">
          <div className="container">
            <h2>Questions, answered</h2>
            {siteConfig.faqs.map((f, i) => (
              <div className="faq" key={f.q}>
                <button
                  className="faq-q"
                  onClick={() => setOpenFaq(openFaq === i ? null : i)}
                  aria-expanded={openFaq === i}
                >
                  {f.q} <span>{openFaq === i ? "−" : "+"}</span>
                </button>
                {openFaq === i && <p className="faq-a">{f.a}</p>}
              </div>
            ))}
          </div>
        </section>

        {/* CONTACT / FOOTER */}
        <section className="section section-dark" id="contact">
          <div className="container contact-grid">
            <div>
              <h2>Talk to a roofer, not a call center</h2>
              <p className="lede">
                {c.hours}. Emergency leaks — call any time, day or night.
              </p>
              <p className="contact-big">
                <a href={c.phoneHref}>{c.phoneDisplay}</a>
              </p>
              <p>
                <a href={`mailto:${c.email}`}>{c.email}</a>
                <br />
                {c.address}
              </p>
            </div>
            <div>
              <h3>Service area</h3>
              <p>{siteConfig.serviceArea.cities.join(" · ")}</p>
              <h3>How payment works</h3>
              <ol className="steps">
                <li>Free estimate — request it above.</li>
                <li>$500 deposit through Whop checkout locks your date.</li>
                <li>We do the job. You walk through it with us.</li>
                <li>Final balance by Whop invoice — auto-charged to your saved card, or paid manually.</li>
              </ol>
            </div>
          </div>
        </section>
      </main>

      <footer className="footer">
        <div className="container">
          <p>
            © {new Date().getFullYear()} {c.name} · {c.license} · Payments
            processed by Whop. This is a reusable template — swap the company
            details in <code>src/config.ts</code>.
          </p>
        </div>
      </footer>

      {checkoutPlan && (
        <CheckoutModal plan={checkoutPlan} onClose={() => setCheckoutPlan(null)} />
      )}
      {saveCardOpen && <SaveCardModal onClose={() => setSaveCardOpen(false)} />}
    </div>
  );
}
