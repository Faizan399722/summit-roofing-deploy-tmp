/**
 * Whop pixel tracking.
 *
 * Docs: docs.whop.com/developer/websites/tracking
 * - Whop injects the pixel into every HTML page the site serves and fires
 *   page views automatically. Checkout views, purchases, subscriptions and
 *   trials are also automatic on whop.app / whop.site.
 * - `window.whop` exists before app code runs, so call it directly.
 * - Custom event names work as-is and show up under that name in reporting.
 *   Standard names (lead, schedule, view_content, add_to_cart,
 *   initiate_checkout) optionally take `value` and `currency`.
 *
 * This wrapper is a safe no-op when the pixel is absent (local dev outside
 * Whop hosting), and logs to the console in dev so the events are verifiable
 * without a live Whop dashboard. It never throws.
 */

declare global {
  interface Window {
    whop?: {
      track: (event: string, data?: Record<string, unknown>) => void;
    };
  }
}

export type TrackEventName =
  | "estimate_requested"
  | "service_viewed"
  | "deposit_started"
  | "lead"
  | "view_content"
  | "add_to_cart"
  | "initiate_checkout"
  | "contact";

export function trackWhop(
  event: TrackEventName,
  data?: Record<string, unknown>,
): void {
  try {
    if (typeof window !== "undefined" && window.whop?.track) {
      window.whop.track(event, data);
    } else if (typeof window !== "undefined") {
      // Local dev / non-Whop preview: visible in the console, never an error.
      console.info("[whop.track] (pixel not present locally)", event, data ?? {});
    }
  } catch (err) {
    console.warn("[whop.track] failed", event, err);
  }
}

/** Fired when a service card / service section is viewed or opened. */
export function trackServiceViewed(serviceKey: string, serviceName: string) {
  trackWhop("service_viewed", { service: serviceKey, service_name: serviceName });
  trackWhop("view_content", { content_type: "service", content_id: serviceKey });
}

/** Fired when the estimate form is submitted successfully (lead created). */
export function trackEstimateRequested(serviceKey?: string) {
  trackWhop("estimate_requested", { service: serviceKey ?? "general" });
  // Standard name too, so the lead counts in Whop's built-in lead reporting.
  trackWhop("lead", { source: "estimate_form" });
}

/** Fired when a deposit checkout is opened. */
export function trackDepositStarted() {
  trackWhop("deposit_started", { value: 500, currency: "USD" });
  trackWhop("initiate_checkout", { value: 500, currency: "USD" });
}
