/** Typed client for the template's own server API routes. */

export interface EstimatePayload {
  name: string;
  email: string;
  phone: string;
  address: string;
  zip: string;
  service: string;
  details: string;
}

export interface ApiError {
  error: string;
  details?: string;
  /** Set when the server is missing configuration (e.g. no API key). */
  missingConfig?: boolean;
}

async function postJson<T>(path: string, body: unknown): Promise<T> {
  const res = await fetch(path, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  const data = (await res.json().catch(() => ({}))) as T & Partial<ApiError>;
  if (!res.ok) {
    const err = new Error(
      data.error || `Request failed (${res.status})`,
    ) as Error & { missingConfig?: boolean; status?: number };
    err.missingConfig = data.missingConfig;
    err.status = res.status;
    throw err;
  }
  return data;
}

export async function submitEstimate(
  payload: EstimatePayload,
): Promise<{ leadId?: string; ok: boolean }> {
  return postJson("/api/leads", payload);
}

export async function createCheckoutConfiguration(input: {
  planId: string;
  mode?: "payment" | "setup";
}): Promise<{ checkoutConfigurationId: string; purchaseUrl?: string }> {
  return postJson("/api/checkout-configurations", input);
}

export async function createSetupIntent(input: {
  confirmationToken: string;
  email: string;
}): Promise<{ setupIntentId?: string; clientSecret?: string | null; status?: string }> {
  return postJson("/api/setup-intents", input);
}

export async function createFinalBalanceInvoice(input: {
  email: string;
  customerName: string;
  planId: string;
  paymentMethodId?: string;
  dueDays?: number;
  action?: "create" | "issue" | "send";
  memo?: string;
}): Promise<{
  invoiceId: string;
  status: string;
  total?: number;
  checkoutLink?: string | null;
}> {
  return postJson("/api/invoices", input);
}

export async function getHealth(): Promise<{ ok: boolean; whopConfigured: boolean }> {
  const res = await fetch("/api/health");
  return (await res.json()) as { ok: boolean; whopConfigured: boolean };
}
