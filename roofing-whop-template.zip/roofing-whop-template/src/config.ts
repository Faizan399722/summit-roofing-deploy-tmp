/**
 * THE ONLY FILE A NEW ROOFING COMPANY NEEDS TO EDIT.
 *
 * Swap the values below — company name, phone, service area, services,
 * reviews, and plan IDs — and the whole site (hero, services, pricing,
 * checkout, estimate form, invoice flow) updates. No structural changes.
 *
 * PLAN IDS: create the 3 plans in Whop first (see README "Create the plans"
 * or run `npm run create-plans`), then paste the real `plan_…` IDs here.
 * Until a plan ID is real, its checkout button is disabled with a clear
 * "not configured yet" note — the site never pretends to sell what it can't.
 */

export interface RoofingPlan {
  /** Key used by the UI + server routes. Do not rename. */
  key: "inspection" | "deposit" | "repair";
  /** Display name shown on the pricing card and in checkout. */
  name: string;
  /** Short pitch line. */
  blurb: string;
  /** Price in USD major units, e.g. 149 = $149.00. */
  priceUsd: number;
  /** What the price covers. */
  includes: string[];
  /** Whop plan (variant) ID, prefixed `plan_`. Placeholder until configured. */
  planId: string;
  /** "one-time" for all three plans in this template. */
  billing: "one-time";
  /** Deposit-only: does this plan save the card for the final balance? */
  savesCardForFinalBalance?: boolean;
}

export interface RoofingService {
  key: string;
  name: string;
  tagline: string;
  description: string;
  /** Starting price shown on the card, or null to show "Free estimate". */
  fromUsd: number | null;
  bullets: string[];
  /** Which plan this service books through. */
  planKey: RoofingPlan["key"];
}

export const siteConfig = {
  company: {
    name: "Summit Roofing Co.",
    tagline: "Roofs done right. Priced up front. Guaranteed in writing.",
    phoneDisplay: "(555) 013-4477",
    phoneHref: "tel:+15550134477",
    email: "hello@summitroofing.example",
    address: "1200 Ridge Road, Denver, CO 80202",
    license: "Licensed & Insured — CO License #RC-10482",
    hours: "Mon–Sat, 7am–7pm · Emergency leaks 24/7",
    // Whop account (company) ID — used by the server for Leads/Invoices.
    // The client never sees the API key; the account ID is public-ish and
    // is also required by the Payments elements. Replace with the real biz_.
    whopAccountId: "biz_REPLACE_ME",
    // Whop product ID for the estimate-form lead (optional; leave the
    // placeholder and leads are still created, just without a product link).
    whopProductId: "prod_REPLACE_ME",
  },

  hero: {
    headline: "A roof you never have to worry about again.",
    subheadline:
      "Repair, replacement, and inspection from a local, licensed crew — with the price in writing before we start, a $500 deposit to lock your date, and financing at checkout.",
    primaryCta: "Request a free estimate",
    secondaryCta: "Book a $149 inspection",
    trustPoints: [
      "4.9★ from 312 verified reviews",
      "50-year workmanship warranty",
      "Same-week scheduling",
    ],
  },

  serviceArea: {
    heading: "We serve the Denver metro area",
    note: "Not sure if we cover your town? Send an estimate request — if we can't reach you, we'll tell you within one business day and refer you to someone we trust.",
    cities: [
      "Denver",
      "Aurora",
      "Lakewood",
      "Arvada",
      "Centennial",
      "Littleton",
      "Thornton",
      "Westminster",
      "Boulder",
      "Golden",
      "Highlands Ranch",
      "Castle Rock",
    ],
  },

  financing: {
    heading: "Don't let the roof wait. Pay over time.",
    body: "Checkout runs entirely on Whop, so approved buyers see financing options — Klarna, Splitit, Afterpay and more — right inside the payment step, with no extra forms and no custom card handling on this site. Availability and terms depend on the buyer and the merchant's Whop setup; we never promise a financing approval.",
    points: [
      "Financing shows automatically at checkout for approved merchants",
      "Apple Pay / Google Pay one-tap checkout",
      "Deposit now, final balance by invoice when the job is done",
    ],
  },

  services: [
    {
      key: "repair",
      name: "Roof Repair",
      tagline: "Leaks fixed fast — usually the same week.",
      description:
        "From a single missing shingle to storm damage and flashing failures, we find the real source of the leak, fix it, and show you photos of the work.",
      fromUsd: 1899,
      bullets: [
        "Leak detection + photo report",
        "Shingle, flashing & vent repair",
        "Storm & hail damage repair",
        "2-year repair workmanship warranty",
      ],
      planKey: "repair",
    },
    {
      key: "replacement",
      name: "Full Roof Replacement",
      tagline: "A new roof, priced in writing, done in days.",
      description:
        "Tear-off and replacement in architectural shingle, metal, or flat roofing. You pay a $500 deposit to lock your date; the balance is invoiced only when the job is finished and inspected.",
      fromUsd: null,
      bullets: [
        "Free detailed written estimate",
        "$500 deposit locks your install date",
        "Final balance by invoice after completion",
        "50-year workmanship warranty",
      ],
      planKey: "deposit",
    },
    {
      key: "inspection",
      name: "Roof Inspection",
      tagline: "Know exactly where your roof stands.",
      description:
        "A 21-point inspection with photos, a written condition report, and an honest repair-vs-replace recommendation — no pressure to buy a new roof.",
      fromUsd: 149,
      bullets: [
        "21-point inspection + photos",
        "Written report within 24 hours",
        "Repair-vs-replace recommendation",
        "Report accepted by insurers & buyers",
      ],
      planKey: "inspection",
    },
  ] as RoofingService[],

  plans: [
    {
      key: "inspection",
      name: "Roof Inspection",
      blurb: "21-point inspection with a written photo report.",
      priceUsd: 149,
      includes: [
        "Full 21-point roof inspection",
        "Photo report within 24 hours",
        "Repair-vs-replace recommendation",
      ],
      planId: "plan_REPLACE_ME_INSPECTION",
      billing: "one-time",
    },
    {
      key: "deposit",
      name: "Project Deposit",
      blurb: "Lock your replacement date. Card saved for the final balance.",
      priceUsd: 500,
      includes: [
        "Locks your install date",
        "Applied in full to your project total",
        "Card saved on file for the final invoice",
        "Fully refundable until work begins",
      ],
      planId: "plan_REPLACE_ME_DEPOSIT",
      billing: "one-time",
      savesCardForFinalBalance: true,
    },
    {
      key: "repair",
      name: "Roof Repair Package",
      blurb: "Flat-rate repair — one price, no surprises.",
      priceUsd: 1899,
      includes: [
        "Leak detection + repair (up to 100 sq ft)",
        "Shingles, flashing & vents included",
        "Photo report of the completed work",
        "2-year workmanship warranty",
      ],
      planId: "plan_REPLACE_ME_REPAIR",
      billing: "one-time",
    },
  ] as RoofingPlan[],

  reviews: [
    {
      name: "Maria G. — Denver",
      stars: 5,
      text: "They found the leak two other companies missed, fixed it the same week, and the price was exactly what the estimate said. Photos of everything.",
    },
    {
      name: "James & Priya R. — Aurora",
      stars: 5,
      text: "Full replacement in three days. The $500 deposit locked our date, and we only paid the balance after the final walkthrough. Zero surprises.",
    },
    {
      name: "Tom W. — Lakewood",
      stars: 5,
      text: "The $149 inspection report got our insurance claim approved. Honest about what needed fixing and what didn't.",
    },
    {
      name: "Dana S. — Centennial",
      stars: 5,
      text: "Financing at checkout meant we didn't have to wait another winter with a bad roof. Crew was clean, fast, and polite.",
    },
  ],

  faqs: [
    {
      q: "How does the deposit work?",
      a: "You pay a $500 deposit through Whop checkout to lock your install date. Your card is saved on file (with your consent) so the final balance can be billed by invoice when the job is done — or you can pay the invoice manually instead.",
    },
    {
      q: "When do I pay the final balance?",
      a: "Only after the job is finished and you've done the final walkthrough with us. We then send a Whop invoice for the remaining balance, due within 14 days.",
    },
    {
      q: "Is financing really available?",
      a: "Financing options such as Klarna, Splitit, and Afterpay appear inside Whop checkout automatically for approved merchants and buyers. We don't run credit checks on this site and can't guarantee an approval.",
    },
    {
      q: "What if it rains on install day?",
      a: "We watch the forecast and reschedule at no cost to you. Your deposit stays applied to the project — it is never lost to weather.",
    },
  ],
} as const;

/** True only when the plan ID looks like a real Whop plan ID. */
export function isPlanConfigured(plan: RoofingPlan): boolean {
  return plan.planId.startsWith("plan_") && !plan.planId.includes("REPLACE_ME");
}

export function getPlan(key: RoofingPlan["key"]): RoofingPlan {
  const plan = siteConfig.plans.find((p) => p.key === key);
  if (!plan) throw new Error(`Unknown plan key: ${key}`);
  return plan;
}

export function formatUsd(amountUsd: number): string {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    maximumFractionDigits: 0,
  }).format(amountUsd);
}
