/**
 * Whop Websites server for the roofing template.
 *
 * Serves the built client (dist/client) and the API routes the site needs:
 *
 *   GET  /api/health                  — is Whop configured on this server?
 *   GET  /api/config                  — public site config (no secrets)
 *   POST /api/leads                   — estimate form -> Whop Leads API
 *   POST /api/checkout-configurations — mint a Whop checkout configuration
 *                                        (payment or setup mode)
 *   POST /api/setup-intents           — confirmation token -> setup intent
 *                                        (card-on-file for the final balance)
 *   POST /api/invoices                — final-balance invoice: create a draft,
 *                                        then issue (auto-charge saved card)
 *                                        or send (email for manual payment)
 *
 * Build layout (Whop Websites quickstart): static in dist/client, this
 * bundle in dist/server. `whop apps deploy` runs `npm run build` + typecheck.
 */
import http from "node:http";
import { randomUUID } from "node:crypto";
import { readFile } from "node:fs/promises";
import { existsSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { siteConfig, getPlan, isPlanConfigured } from "../config.js";
import { callWhop, readWhopEnv, requireWhopConfig, WhopError } from "./whop.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
// dist/server/index.js -> dist/client
const CLIENT_DIR = path.resolve(__dirname, "../client");
const PORT = Number(process.env.PORT || 3000);

const MIME: Record<string, string> = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".svg": "image/svg+xml",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".ico": "image/x-icon",
  ".woff2": "font/woff2",
};

type Json = Record<string, unknown>;

function sendJson(res: http.ServerResponse, status: number, body: Json) {
  res.writeHead(status, { "Content-Type": "application/json; charset=utf-8" });
  res.end(JSON.stringify(body));
}

function sendError(res: http.ServerResponse, err: unknown) {
  if (err instanceof WhopError) {
    sendJson(res, err.status, {
      error: err.message,
      missingConfig: err.status === 503,
      details: err.whopBody ?? undefined,
    });
    return;
  }
  console.error(err);
  sendJson(res, 500, { error: "Internal server error" });
}

async function readJsonBody(req: http.IncomingMessage): Promise<Json> {
  const chunks: Buffer[] = [];
  for await (const chunk of req) chunks.push(chunk as Buffer);
  const text = Buffer.concat(chunks).toString("utf-8");
  if (!text.trim()) return {};
  try {
    return JSON.parse(text) as Json;
  } catch {
    throw new WhopError(400, "Request body must be valid JSON.");
  }
}

function requireString(body: Json, field: string): string {
  const v = body[field];
  if (typeof v !== "string" || !v.trim()) {
    throw new WhopError(400, `Field "${field}" is required.`);
  }
  return v.trim();
}

async function handleApi(
  req: http.IncomingMessage,
  res: http.ServerResponse,
  pathname: string,
): Promise<boolean> {
  const env = readWhopEnv();

  // ---- GET /api/health -------------------------------------------------
  if (req.method === "GET" && pathname === "/api/health") {
    sendJson(res, 200, {
      ok: true,
      whopConfigured: Boolean(env.apiKey && env.accountId),
    });
    return true;
  }

  // ---- GET /api/config (public, no secrets) ---------------------------
  if (req.method === "GET" && pathname === "/api/config") {
    sendJson(res, 200, {
      company: siteConfig.company,
      plans: siteConfig.plans.map((p) => ({
        key: p.key,
        name: p.name,
        priceUsd: p.priceUsd,
        configured: isPlanConfigured(p),
      })),
    });
    return true;
  }

  if (req.method !== "POST") return false;

  // ---- POST /api/leads --------------------------------------------------
  // Estimate form -> Whop Leads API (POST /leads, CreateLeadV2).
  // NOTE (verified against the OpenAPI spec): the Leads resource takes no
  // name/email/phone fields — identity is the Whop user (user_id) or the
  // signed-in visitor. The form's contact details therefore go in
  // `metadata` (string values), which is exactly what Whop shows on the lead.
  if (pathname === "/api/leads") {
    const body = await readJsonBody(req);
    const name = requireString(body, "name");
    const email = requireString(body, "email");
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      throw new WhopError(400, "A valid email address is required.");
    }
    const phone = typeof body.phone === "string" ? body.phone.trim() : "";
    const address = typeof body.address === "string" ? body.address.trim() : "";
    const zip = typeof body.zip === "string" ? body.zip.trim() : "";
    const service = typeof body.service === "string" ? body.service.trim() : "general";
    const details = typeof body.details === "string" ? body.details.trim() : "";
    const productId = siteConfig.company.whopProductId;
    const lead = await callWhop<{ id?: string }>(env, "/leads", {
      method: "POST",
      idempotencyKey: randomUUID(),
      body: {
        account_id: env.accountId,
        ...(productId && !productId.includes("REPLACE_ME")
          ? { product_id: productId }
          : {}),
        referrer: req.headers.referer ?? undefined,
        metadata: {
          name,
          email,
          phone,
          address,
          zip,
          service,
          details,
          source: "roofing-template-estimate-form",
        },
      },
    });
    sendJson(res, 201, { ok: true, leadId: lead.id ?? null });
    return true;
  }

  // ---- POST /api/checkout-configurations --------------------------------
  // Mints a reusable Whop checkout configuration for a plan, in `payment`
  // mode (charge now) or `setup` mode (save a card, charge $0 now).
  // The client mounts it with <Checkout checkoutConfiguration={id}>.
  // OpenAPI: POST /checkout_configurations { account_id, variant_id, mode }.
  if (pathname === "/api/checkout-configurations") {
    const body = await readJsonBody(req);
    const planKey = requireString(body, "planId");
    const mode = body.mode === "setup" ? "setup" : "payment";
    const plan = getPlan(planKey as never);
    if (!isPlanConfigured(plan)) {
      throw new WhopError(
        503,
        `Plan "${plan.name}" is not configured yet — paste its real plan_ ID into src/config.ts first.`,
      );
    }
    const cfg = await callWhop<{ id: string; purchase_url?: string }>(
      env,
      "/checkout_configurations",
      {
        method: "POST",
        idempotencyKey: randomUUID(),
        body: {
          account_id: env.accountId,
          variant_id: plan.planId,
          mode,
          metadata: { source: "roofing-template", plan: plan.key },
        },
      },
    );
    sendJson(res, 201, {
      checkoutConfigurationId: cfg.id,
      purchaseUrl: cfg.purchase_url ?? null,
    });
    return true;
  }

  // ---- POST /api/setup-intents ------------------------------------------
  // Turns a confirmation token (from Payments mode="setup" +
  // createConfirmationToken()) into a setup intent. The response carries
  // client_secret for any next action (3DS etc.) via handleNextAction().
  // Webhook to watch: setup_intent.succeeded -> payment_method_id (payt_).
  if (pathname === "/api/setup-intents") {
    const body = await readJsonBody(req);
    const confirmationToken = requireString(body, "confirmationToken");
    const email = requireString(body, "email");
    const intent = await callWhop<{
      id?: string;
      client_secret?: string | null;
      status?: string;
    }>(env, "/setup_intents", {
      method: "POST",
      idempotencyKey: randomUUID(),
      body: {
        account_id: env.accountId,
        confirmation_token: confirmationToken,
        currency: "usd",
        email,
        metadata: { source: "roofing-template-card-on-file" },
      },
    });
    sendJson(res, 201, {
      setupIntentId: intent.id ?? null,
      clientSecret: intent.client_secret ?? null,
      status: intent.status ?? null,
    });
    return true;
  }

  // ---- POST /api/invoices ------------------------------------------------
  // Final-balance invoice (native Invoices API, Api-Version-Date 2026-10-24+).
  // Flow: create draft (charges nothing, emails nobody) -> optionally
  // issue (auto-charges payment_method_id off-session at charge_at/due_at,
  // otherwise right away) or send (issue + email for manual payment).
  // TODO (per job, in the pitch / admin step): pass the real member's
  // payment_method_id (payt_…) saved at deposit time, and the real final
  // amount. This template bills the deposit plan's variant by default;
  // for a custom final total, create a one-time variant for that amount
  // first (see README "Final balance") and pass its planId.
  if (pathname === "/api/invoices") {
    const body = await readJsonBody(req);
    const email = requireString(body, "email");
    const customerName = requireString(body, "customerName");
    const planKey = requireString(body, "planId");
    const plan = getPlan(planKey as never);
    if (!isPlanConfigured(plan)) {
      throw new WhopError(
        503,
        `Plan "${plan.name}" is not configured yet — paste its real plan_ ID into src/config.ts first.`,
      );
    }
    const action = body.action === "issue" || body.action === "send" ? body.action : "create";
    const dueDays = typeof body.dueDays === "number" ? body.dueDays : 14;
    const dueAt = new Date(Date.now() + dueDays * 24 * 60 * 60 * 1000).toISOString();
    const paymentMethodId =
      typeof body.paymentMethodId === "string" && body.paymentMethodId.trim()
        ? body.paymentMethodId.trim()
        : undefined;
    const memo = typeof body.memo === "string" ? body.memo.trim() : undefined;

    const draft = await callWhop<{
      id: string;
      status?: string;
      total?: number;
      checkout_link?: string | null;
    }>(env, "/invoices", {
      method: "POST",
      idempotencyKey: randomUUID(),
      versionDate: "2026-10-24",
      body: {
        account_id: env.accountId,
        items: [{ plan_id: plan.planId }],
        email_address: email,
        customer_name: customerName,
        due_at: dueAt,
        ...(paymentMethodId ? { payment_method_id: paymentMethodId } : {}),
        ...(memo ? { memo } : {}),
        metadata: { source: "roofing-template-final-balance", plan: plan.key },
      },
    });

    let invoice = draft;
    if (action === "issue" || action === "send") {
      invoice = await callWhop(env, `/invoices/${draft.id}/${action}`, {
        method: "POST",
        idempotencyKey: randomUUID(),
        versionDate: "2026-10-24",
      });
    }
    sendJson(res, 201, {
      invoiceId: invoice.id,
      status: invoice.status ?? (action === "create" ? "draft" : "open"),
      total: invoice.total ?? null,
      checkoutLink: invoice.checkout_link ?? null,
    });
    return true;
  }

  return false;
}

async function serveStatic(
  req: http.IncomingMessage,
  res: http.ServerResponse,
  pathname: string,
) {
  const safePath = pathname === "/" ? "/index.html" : pathname;
  const filePath = path.join(CLIENT_DIR, decodeURIComponent(safePath));
  if (!filePath.startsWith(CLIENT_DIR) || !existsSync(filePath)) {
    // SPA fallback: unknown paths serve the app shell.
    const index = path.join(CLIENT_DIR, "index.html");
    if (existsSync(index)) {
      const html = await readFile(index);
      res.writeHead(200, { "Content-Type": MIME[".html"] });
      res.end(html);
      return;
    }
    res.writeHead(404, { "Content-Type": "text/plain" });
    res.end("Not found — run `npm run build` first.");
    return;
  }
  const ext = path.extname(filePath);
  const data = await readFile(filePath);
  res.writeHead(200, { "Content-Type": MIME[ext] ?? "application/octet-stream" });
  res.end(data);
}

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url ?? "/", `http://${req.headers.host ?? "localhost"}`);
    if (url.pathname.startsWith("/api/")) {
      const handled = await handleApi(req, res, url.pathname);
      if (!handled) sendJson(res, 404, { error: `Unknown API route: ${url.pathname}` });
      return;
    }
    await serveStatic(req, res, url.pathname);
  } catch (err) {
    if (!res.headersSent) sendError(res, err);
  }
});

server.listen(PORT, () => {
  const env = readWhopEnv();
  console.log(`Roofing template server listening on http://localhost:${PORT}`);
  console.log(
    `Whop configured: ${Boolean(env.apiKey && env.accountId) ? "yes" : "NO — set WHOP_API_KEY + WHOP_ACCOUNT_ID (see .env.example)"}`,
  );
  try {
    requireWhopConfig(env);
  } catch {
    // Startup warning only — the site still serves; API routes fail gracefully.
  }
});
