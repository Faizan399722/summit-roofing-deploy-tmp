/**
 * Minimal server-side Whop API client.
 *
 * - Base URL: https://api.whop.com/api/v1 (or the sandbox base from env).
 * - Auth: `Authorization: Bearer <WHOP_API_KEY>` — server only, never in
 *   browser code. Key scopes are listed in .env.example.
 * - Version: `Api-Version-Date` header on every request. Native Invoices
 *   require 2026-10-24 or later; that is the default (see .env.example).
 * - Errors from Whop are passed through with their status + message.
 *   This server NEVER fabricates a success: if Whop says no, the caller
 *   gets Whop's error.
 *
 * Endpoints verified against Whop's OpenAPI spec
 * (https://api.whop.com/api/v1/openapi.json, fetched 2026-11-10):
 *   POST /leads                  — CreateLeadV2 (account_id required)
 *   POST /checkout_configurations — variant_id, mode: payment | setup
 *   POST /setup_intents          — confirmation_token or payment_method_id
 *   POST /invoices               — account_id + items[] required (native)
 *   POST /invoices/{id}/issue    — issue a draft (charges a saved method)
 *   POST /invoices/{id}/send     — issue + email the invoice
 */

export interface WhopEnv {
  apiKey: string | undefined;
  accountId: string | undefined;
  baseUrl: string;
  versionDate: string;
}

export function readWhopEnv(): WhopEnv {
  return {
    apiKey: process.env.WHOP_API_KEY || undefined,
    accountId: process.env.WHOP_ACCOUNT_ID || undefined,
    baseUrl:
      process.env.WHOP_API_BASE_URL || "https://api.whop.com/api/v1",
    versionDate: process.env.WHOP_API_VERSION_DATE || "2026-10-24",
  };
}

export class WhopError extends Error {
  status: number;
  whopBody: unknown;
  constructor(status: number, message: string, whopBody?: unknown) {
    super(message);
    this.status = status;
    this.whopBody = whopBody;
  }
}

export function requireWhopConfig(env: WhopEnv): void {
  if (!env.apiKey || !env.accountId) {
    const missing = [
      !env.apiKey ? "WHOP_API_KEY" : null,
      !env.accountId ? "WHOP_ACCOUNT_ID" : null,
    ]
      .filter(Boolean)
      .join(", ");
    throw new WhopError(
      503,
      `Whop is not configured on this server — missing ${missing}. ` +
        `Set them in .env (local) or as Whop app secrets (whop apps secrets set). ` +
        `No lead, checkout, setup-intent, or invoice was created.`,
    );
  }
}

export async function callWhop<T>(
  env: WhopEnv,
  path: string,
  options: {
    method?: string;
    body?: unknown;
    idempotencyKey?: string;
    /** Native Invoices need 2026-10-24+; defaults to env version date. */
    versionDate?: string;
  } = {},
): Promise<T> {
  requireWhopConfig(env);
  const res = await fetch(`${env.baseUrl.replace(/\/$/, "")}${path}`, {
    method: options.method ?? "GET",
    headers: {
      Authorization: `Bearer ${env.apiKey}`,
      "Content-Type": "application/json",
      "Api-Version-Date": options.versionDate ?? env.versionDate,
      ...(options.idempotencyKey
        ? { "Idempotency-Key": options.idempotencyKey }
        : {}),
    },
    body: options.body === undefined ? undefined : JSON.stringify(options.body),
  });

  const text = await res.text();
  const data = text ? (JSON.parse(text) as Record<string, unknown>) : {};

  if (!res.ok) {
    const message =
      (typeof data?.message === "string" && data.message) ||
      (typeof data?.error === "string" && data.error) ||
      `Whop API error (${res.status})`;
    throw new WhopError(res.status, message, data);
  }
  return data as T;
}
