#!/usr/bin/env node
/**
 * Create the 3 Whop plans for the roofing template (one-time, buy_now).
 *
 * Usage:
 *   WHOP_API_KEY=... WHOP_ACCOUNT_ID=biz_... node scripts/create-plans.mjs
 *   # or: WHOP_API_KEY=... WHOP_ACCOUNT_ID=biz_... npm run create-plans
 *
 * What it does:
 *   1. Creates one Whop product ("Roofing Services") if ROOFING_PRODUCT_ID
 *      is not set (POST /products).
 *   2. Creates 3 one-time plans under it (POST /plans):
 *        Roof Inspection        $149   plan_type one_time
 *        Project Deposit        $500   plan_type one_time
 *        Roof Repair Package  $1,899   plan_type one_time
 *   3. Prints the plan IDs — paste them into src/config.ts (plans[].planId)
 *      and set WHOP_ACCOUNT_ID in .env / app secrets.
 *
 * Verify-against-docs note (2026-11-10): plan creation fields below follow
 * the Current API shape used by Whop's own checkout-configuration examples
 * (plan_type one_time, initial_price in major units, currency usd,
 * release_method buy_now). If Whop returns a 400/422, read the error body —
 * it names the field — and check docs.whop.com/api-reference/plans before
 * re-running. This script never charges anyone; plans are just price points.
 */
const BASE = process.env.WHOP_API_BASE_URL || "https://api.whop.com/api/v1";
const VERSION = process.env.WHOP_API_VERSION_DATE || "2026-10-24";
const API_KEY = process.env.WHOP_API_KEY;
const ACCOUNT_ID = process.env.WHOP_ACCOUNT_ID;

if (!API_KEY || !ACCOUNT_ID) {
  console.error("Missing WHOP_API_KEY and/or WHOP_ACCOUNT_ID.");
  console.error("Set them in your environment — never commit them. See .env.example.");
  process.exit(1);
}

async function whop(path, body) {
  const res = await fetch(`${BASE}${path}`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${API_KEY}`,
      "Content-Type": "application/json",
      "Api-Version-Date": VERSION,
    },
    body: JSON.stringify(body),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    console.error(`\n${path} failed (${res.status}):`, JSON.stringify(data, null, 2));
    process.exit(1);
  }
  return data;
}

const PLANS = [
  { name: "Roof Inspection", price: 149, description: "21-point roof inspection with written photo report." },
  { name: "Project Deposit", price: 500, description: "Deposit to lock a roof replacement date. Applied in full to the project total." },
  { name: "Roof Repair Package", price: 1899, description: "Flat-rate roof repair package — leak detection and repair up to 100 sq ft." },
];

let productId = process.env.ROOFING_PRODUCT_ID;
if (!productId) {
  const product = await whop("/products", {
    account_id: ACCOUNT_ID,
    name: "Roofing Services",
    description: "Roof inspection, project deposit, and flat-rate repair — sold through the roofing website template.",
    // product_type defaults to a regular product; keep the default.
  });
  productId = product.id;
  console.log(`Product created: ${productId}`);
} else {
  console.log(`Using existing product: ${productId}`);
}

console.log("\nPaste these into src/config.ts (plans[].planId):");
for (const plan of PLANS) {
  const created = await whop("/plans", {
    account_id: ACCOUNT_ID,
    product_id: productId,
    plan_type: "one_time",
    initial_price: plan.price,
    currency: "usd",
    release_method: "buy_now",
    // Title/description field names follow the plan resource; if Whop
    // rejects them, the error body names the correct field.
    title: plan.name,
    description: plan.description,
  });
  console.log(`  ${plan.name} ($${plan.price}): ${created.id}`);
}
console.log("\nDone. Also set whopProductId in src/config.ts to the product ID above if you want estimate leads linked to it.");
