import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import { whop } from "@whop/cli/vite";

/**
 * Whop Websites build layout (docs.whop.com/developer/websites/quickstart):
 * static assets -> dist/client, server bundle -> dist/server.
 * The `whop()` plugin packs dist/ into the archive `whop apps deploy` uploads.
 */
export default defineConfig({
  plugins: [react(), whop()],
  build: {
    outDir: "dist/client",
    emptyOutDir: true,
  },
  server: {
    port: 5173,
    // During local dev, /api/* is served by `npm run start` (dist/server) or
    // proxied to it. Run `npm run build && npm start` for the full local stack.
    proxy: {
      "/api": "http://localhost:3000",
    },
  },
});
