# Roofing Website Template for Whop Websites

A production-ready, original website template for a **US roofing company**,
built on **Whop Websites** — designed to pitch real roofing businesses and
demo Whop end-to-end: estimate → deposit → job → final invoice.

> **Live URL:** none yet — this repo is the complete local template.
> Deploy with `whop apps deploy` (see "Deploy" below). Whop Websites serve
> at `*.whop.site` (the brief's "whop.app" address is the same Whop
> Websites hosting; the current docs name the address `*.whop.site`).

## The flow it demos

| Step | What happens | Whop feature |
|---|---|---|
| 1. Estimate | Visitor fills "Request an Estimate" | **Leads API** — `POST /leads`, lands as a lead on the account |
| 2. Inspection / repair | Visitor buys a one-time plan | **CheckoutElement** (full Whop checkout) |
| 3. Deposit | $500 to lock the install date | **ExpressCheckoutElement** (Apple Pay / Google Pay) + **CheckoutElement** toggle; card saved for the final balance |
| 4. Card on file | Homeowner saves a card ($0 now) | **Payments `mode="setup"` + `setupFutureUsage: "off_session"`** → setup intent; **BrandingElement** (required) |
| 5. Final balance | Office bills the balance after the job | **Invoices API** — draft → issue (auto-charge saved card) or send (email, manual payment) |
| 6. Financing | Klarna / Splitit / Afterpay at checkout | Surfaces automatically inside Whop checkout for approved merchants — **no financing code in this template** |
| 7. Tracking | `estimate_requested`, `service_viewed`, `deposit_started` | `whop.track` (page views + checkout events are automatic on Whop hosting) |

**Whop Payments only.** No Stripe, no PayPal SDK, no custom card forms —
card numbers never touch this code; they live inside Whop's elements.

## Configure — one file

Edit **`src/config.ts`** only. Everything else reads from it:

- Company name, phone, email, address, license, hours
- Service area (cities), services, reviews, FAQs
- **Plans** (name, price, includes, `planId`)

```ts
plans: [
  { key: "inspection", name: "Roof Inspection",      priceUsd: 149,  planId: "plan_…" },
  { key: "deposit",    name: "Project Deposit",      priceUsd: 500,  planId: "plan_…" },
  { key: "repair",     name: "Roof Repair Package",  priceUsd: 1899, planId: "plan_…" },
]
```

Until a plan ID is a real `plan_…` value, its checkout button is disabled
with a "not configured yet" note — the site never pretends to sell what it
can't. Swapping company/services/pricing needs no structural changes.

## Create the plans in Whop

Option A — script (needs an Account API key, see "Env vars"):

```bash
WHOP_API_KEY=... WHOP_ACCOUNT_ID=biz_... npm run create-plans
# prints the 3 plan IDs — paste them into src/config.ts
```

Option B — dashboard: Products → Create product "Roofing Services" → add
three **one-time, buy-now** plans: **Roof Inspection $149**, **Project
Deposit $500**, **Roof Repair Package $1,899**. Copy each `plan_…` ID into
`src/config.ts`, and the product `prod_…` ID into `whopProductId` (optional —
leads still work without it).

Also set `whopAccountId` in `src/config.ts` to the real `biz_…`.

## Env vars

Copy `.env.example` to `.env` (local) or set them as app secrets on Whop
(`whop apps secrets set`). Never commit a real key; the client bundle never
sees these values.

| Var | Purpose |
|---|---|
| `WHOP_ACCOUNT_ID` | `biz_…` account the site sells for |
| `WHOP_API_KEY` | Account API key — scopes: `lead:manage`, `member:email:read`, `access_pass:basic:read`, `member:basic:read`, `checkout_configuration:create`, `payment:charge` (+ `payment:setup_intent:read` for setup-intent reads) |
| `WHOP_API_BASE_URL` | `https://api.whop.com/api/v1` (sandbox: `https://sandbox-api.whop.com/api/v1`) |
| `WHOP_API_VERSION_DATE` | `2026-10-24` (native Invoices require this or later) |
| `PORT` | Server port, default `3000` |

## Run locally

```bash
npm install
npm run build        # client -> dist/client, server -> dist/server
npm start            # serves the site + API on http://localhost:3000
npm run dev          # Vite dev server only (port 5173, /api proxied to :3000)
npm run typecheck
```

Without `WHOP_API_KEY` / `WHOP_ACCOUNT_ID`, the site still serves and the
forms render — but every Whop-backed action fails **gracefully with a clear
error** ("Whop is not configured…", "Plan not configured yet"). Nothing is
faked as a success.

## Deploy (Whop Websites)

```bash
whop apps init --app_type website --name "Summit Roofing" --domain summit-roofing
# or link an existing app: whop apps init --app app_xxxxxxxx
whop apps secrets set --secret WHOP_API_KEY=... --secret WHOP_ACCOUNT_ID=biz_...
whop apps dev        # local preview against real Whop data
whop apps deploy     # live at *.whop.site
whop apps deploy --preview   # preview build
```

`whop.app.json` links this directory to the app — replace the placeholder
`app_id` when you link it. The build layout follows the Whop Websites
quickstart: static assets in `dist/client`, server bundle in `dist/server`,
packed by the `whop()` Vite plugin from `@whop/cli/vite`.

## API routes (server, `src/server/`)

| Route | Whop call | Notes |
|---|---|---|
| `GET /api/health` | — | `{ whopConfigured }` |
| `GET /api/config` | — | Public config (no secrets) |
| `POST /api/leads` | `POST /leads` | Estimate form. **Note:** the Leads API takes no name/email/phone fields — identity is the Whop user; the form's contact details are sent in `metadata`, which is what Whop shows on the lead. Requires `WHOP_API_KEY`. |
| `POST /api/checkout-configurations` | `POST /checkout_configurations` | `{ planId, mode: "payment" \| "setup" }` → `{ checkoutConfigurationId, purchaseUrl }`. OpenAPI uses `variant_id`. |
| `POST /api/setup-intents` | `POST /setup_intents` | `{ confirmationToken, email }` → setup intent + `clientSecret` for `handleNextAction()`. Watch `setup_intent.succeeded` for the `payt_…` payment method ID. |
| `POST /api/invoices` | `POST /invoices` (+ `/issue` or `/send`) | `{ email, customerName, planId, paymentMethodId?, dueDays?, action: "create" \| "issue" \| "send" }`. Draft charges nothing; issue auto-charges a saved card; send emails it for manual payment. |

## Checkout details (read before the demo)

- **CheckoutElement vs ExpressCheckoutElement are exclusive** in one
  Checkout handle (Whop docs: "Mount one at a time"). The modal shows the
  express wallets first and swaps to the full form on "Pay with card
  instead" — exactly one is mounted at any moment.
- **BrandingElement is required inside `<Payments>`** — payment/card
  elements stay loading until it is mounted, and payments cannot be
  confirmed without it. It is mounted in the card-on-file flow
  (`src/client/components/CardOnFile.tsx`). The Checkout surface renders
  Whop's own merchant-of-record notice itself.
- **Card-on-file, two documented paths:** (1) standalone setup-mode flow
  in this template — `Payments mode="setup"`, `setupFutureUsage:
  "off_session"`, confirmation token → setup intent; (2) save *during* a
  payment by passing `setupFutureUsage: "off_session"` on the Payments
  handle (see `developer/guides/save-payment-methods`). The deposit
  checkout in this template charges via Checkout; the save step is the
  standalone flow, labelled as such in the UI.
- **Final balance amount:** invoices bill a plan's price. For a custom
  final total, create a one-time variant for that amount first and pass
  its `planId` to the invoice panel / `POST /api/invoices`. The panel
  bills the selected plan's price by default — that is the honest demo
  behaviour, not a silent custom amount.
- **Checkout configurations:** the server mints them with `variant_id`
  (per the OpenAPI spec). Whop's SDK example uses `plan_id` — if a future
  API version rejects `variant_id`, the error body will say so; the fix is
  one field in `src/server/index.ts`.

## Tracking — verify in the Whop pixel dashboard

`window.whop` is injected by Whop hosting before app code runs. Custom
events fired by this template (`src/lib/tracking.ts`):

- `estimate_requested` (+ standard `lead`) — estimate form submitted
- `service_viewed` (+ standard `view_content`) — service card clicked
- `deposit_started` (+ standard `initiate_checkout`, $500 USD) — deposit checkout opened

Page views, checkout views, purchases, subscriptions, and trials are
automatic on Whop hosting. First events appear in the pixel dashboard
about a minute after the visit. Locally (no pixel), events log to the
console as `[whop.track] (pixel not present locally)` — they are never
faked as sent.

## What is verified locally vs what still needs a live Whop account

**Verified locally (2026-11-10):**
- `npm run build` completes cleanly (Vite client → `dist/client`, esbuild
  server → `dist/server/index.js`); `npm run typecheck` passes.
- Server boots and serves the site; `/api/health` reports
  `whopConfigured: false` without a key (correct graceful state).
- Estimate/invoice/checkout-config/setup-intent routes return a clear
  503 "Whop is not configured" without a key — no fake successes.
- All Whop element imports typecheck against `@whop/elements@1.10.0` /
  `@whop/elements-react@1.10.0`; endpoint shapes were checked against
  Whop's OpenAPI spec (`api.whop.com/api/v1/openapi.json`).

**NOT yet tested — needs a live Whop account + key (blockers):**
1. **Whop CLI auth + app link** — `whop apps init --app_type website`
   (needs Faizan's Whop login) and replacing `app_id` in `whop.app.json`.
2. **Real plan IDs** — the 3 plans don't exist yet; `plan_REPLACE_ME_*`
   must be replaced (script or dashboard, above).
3. **Test checkout** — needs (1)+(2) + a Whop test/sandbox buyer; verify
   CheckoutElement + ExpressCheckoutElement + BrandingElement render and a
   test payment completes.
4. **Lead creation** — needs an Account API key with `lead:manage`; submit
   the estimate form and confirm the lead in the Whop dashboard.
5. **Setup intent + invoice** — needs a real saved `payt_…` method; verify
   `setup_intent.succeeded`, then issue an invoice and confirm auto-charge
   vs manual-pay-via-email.
6. **Pixel events** — needs the deployed `*.whop.site` site; verify the
   three custom events in the Whop pixel dashboard.
7. **Financing surfacing** — depends on the merchant's Whop Payments
   setup; Klarna/Splitit/Afterpay appear only for approved merchants.

## Project layout

```
whop.app.json            # links this directory to the Whop app
vite.config.ts           # whop() plugin; build -> dist/client
index.html               # app shell
src/config.ts            # ★ THE config file — edit this to rebrand
src/lib/tracking.ts      # whop.track wrapper (safe no-op locally)
src/lib/api.ts           # typed client for /api/* routes
src/client/              # React site: hero, services, pricing, area,
                         # financing, reviews, estimate form, FAQ, contact
src/client/components/   # CheckoutModal, CardOnFile, EstimateForm, InvoicePanel
src/server/              # Node server: static + /api routes (whop.ts client)
scripts/create-plans.mjs # creates the 3 Whop plans, prints their IDs
```

## License

MIT — original code, built for this template. Swap `src/config.ts` and it
is yours to pitch.
